import React from 'react'
import Question from './question'
import QuestionFour from './questionFour'
import ErrorBoundary from '../../components/errorBoundary'
import Tetris from './tetris/Tetris'

const QuestionOneWrapper = () =>{
	return (
		<ErrorBoundary question={Question}>
			<Tetris/>
		</ErrorBoundary>
	)
}
export default QuestionOneWrapper