import React from 'react';
import './Tetris.css'
class Tetris extends React.Component{
    

    //For HOC
    componentDidMount() {
        this.updateCanvas();
    }
    
    updateCanvas() {
        const ctx = this.refs.canvas.getContext('2d');
        ctx.scale(20,20);

        const matrix = [
            [0,0,0],
            [1,1,1],
            [0,1,0],
        ]

        function collide(arena, player){
            const [m,o] = [player.matrix, player.pos];
            //loops for x and why positions of player
            for (let y =0; y <m.length; ++y){
                    for(let x =0; x < m[y].length; ++x){
                        //condition for matching player x and y posiion and making sure the arena exists
                        if(m[y][x] !==0 && 
                            (arena[y + o.y] && 
                                arena[y + o.y][x + o.x]) !==0 ){
                            return true;//colision is true 
                        }
                    }
            }
            return false;
        }

        function arenaSweep(){
            let rowCount =1;
            //iterate from bottom to top
            outer: for(let y = arena.length - 1; y > 0; --y){

                for( let x =0; x < arena[y].length; ++x){
                    //to check if any of the rows have a 0, i.e whitespace
                    if(arena[y][x] ===0){
                        continue outer;
                    }
                }
                //using splice method as it returns all the elements it has taken out from the array
                const row = arena.splice(y,1)[0].fill(0);//create an empty row at index y and fills it with 0s
                arena.unshift(row);//unshift method fills the row
                ++y;

                //adding to score via row count
                player.score += rowCount * 10;
                rowCount *= 2; //multiply score by two

            }
        }
        //function for collision
        function createMatrix(w,h){

            const matrix = [];//create empty array 
            //condition for handling height when not 0
            while(h--){
                matrix.push(new Array(w).fill(0));
            }
            return matrix;
        }

        function createPiece(type){
            //condiions for creating play types
            if(type === 'T'){
                return  [
                    [0,0,0],
                    [1,1,1],
                    [0,1,0],
                ];
            }else if(type === 'O'){
                return  [
                    [2,2],
                    [2,2],
                    
                ];
            }else if(type === 'L'){
                return  [
        
                    [0,3,0],
                    [0,3,0],
                    [0,3,3],
                    
                ];
            }else if(type === 'J'){
                return  [
        
                    [0,4,0],
                    [0,4,0],
                    [4,4,0],
                    
                ];
            }else if(type === 'I'){
                return  [
        
                    [0,5,0,0],
                    [0,5,0,0],
                    [0,5,0,0],
                    [0,5,0,0],
                ];
            }else if(type === 's'){
                return  [
                    [0,6,6],
                    [6,6,0],
                    [0,0,0],
                ];
            }else if(type === 'Z'){
                return  [
        
                    [7,7,0],
                    [0,7,7],
                    [0,0,0],
                ];
            }

        }

        function draw(){
            
            ctx.fillStyle = '#000';//redraws player object when moving
            ctx.fillRect(0,0, 240, 400);
           
            drawMatrix(arena, {x:0, y:0})//draw arena and set the x and y positions
            drawMatrix(player.matrix, player.pos);//draw player 
        }

        function drawMatrix(matrix, offset){
            matrix.forEach((row, y) =>{
                row.forEach((value, x) =>{
                    if(value !==0){
                        ctx.fillStyle = colors[value];//use colors array 
                        ctx.fillRect(x + offset.x, //for moving pieces use offset.x
                                        y + offset.y,
                                        1,1);
                    }
                });//remember to close loops
            });

        }

        //merg used for building arena and player
        function merge(arena,player){
            player.matrix.forEach((row, y) =>{ //iterate through the row
                    //method if value is not 0
                row.forEach((value, x) =>{
                        if(value !==0){
                            //copy the value to arena at the correct offset
                            arena[y + player.pos.y][x + player.pos.x] = value;
                        }
                       
                });
            });
            
        }


        function playerDrop(){
            player.pos.y++; //increases the player y position
           
            //condition for collision of player and arena
            if(collide(arena, player)){
                player.pos.y--;
                merge(arena, player);
                playerReset();//move player to beggining
                arenaSweep();
                updateScore();
               
            }
            dropCounter = 0;//reset the drop counter for re use
        }

        function playerMove(dir){
            player.pos.x += dir;
            if(collide(arena, player)){
                player.pos.x -= dir;//for collision

            }
        }

        function playerReset(){

            const pieces = 'TOLIJSZ';// conditions from create pieces function
            player.matrix =  createPiece(pieces[pieces.length * Math.random() | 0]);//take all the elements in pieces array
            player.pos.y = 0;
            player.pos.x = (arena[0].length / 2 | 0) -
                            (player.matrix[0].length / 2 | 0);
            //
            //remove everything from arena
            if (collide(arena, player)){
                    arena.forEach(row => row.fill(0));
                   player.score = 0;//reset store after collision
                    updateScore();
            }
        }

        function playerRotate(dir){
            const pos = player.pos.x;//store player position to a constan for resetting
            let offset = 1; 
            rotate(player.matrix, dir);
            //collison detection to prevent player rotating outside boundry
            while(collide(arena, player)){
                player.pos.x += offset;//move to the right
                offset = -(offset+(offset > 0 ? 1 : -1));// move to left if there is still a collision after offset
                
                //to reser rotation and set offset back to 1
                if(offset > player.matrix[0].length){
                    rotate(player.matrix, - dir);
                    player.pos.x = pos; //reset play position using pos
                    return;
                }
            }
        }

        function rotate(matrix, dir){
            //for rotating player
            for (let y =0; y < matrix.length; ++y){
                for (let x=0; x<y; ++x){
                    //transposing player x and y 
                    [
                        matrix[x][y],
                        matrix[y][x]
                    ] = [
                        matrix[y][x],
                        matrix[x][y],
                    ];

                }
            }
            //condition for positive player rotation
            if(dir > 0){
                matrix.forEach(row => row.reverse());

            }else{
                matrix.reverse();
            }
        }
        //Variables for object movement
        let dropCounter = 0;
        let dropInterval = 1000;//dropInterval is in milliseconds
        let lastTime = 0;

        //for update game and use requestAnimationFrame method
        function update(time=0){
            const deltaTime = time - lastTime;
            lastTime = time;
            
            dropCounter += deltaTime;//increments dropCOunter by deltaTime
            //condition for player movement (gravity)
            if(dropCounter > dropInterval){

               playerDrop();//consolidate code
            }

            draw();
            requestAnimationFrame(update);//update as param for method
        }



        
        //array of colours for the player shapes
        const colors = [
            null,
            'red',
            'blue',
            'yellow',
            'purple',
            'green',
            'violet',
            'orange',
            
        ]

        //setting the game boundries
        const arena = createMatrix(12,20);

        const player = {
                pos: {x:0, y:0},
                matrix: null,
                score:0
        }

        function updateScore(){
           document.getElementById('score').innerText = player.score;
        }
        //keyboard controls
        document.addEventListener('keydown', event =>{
          //condition for keyboard event left
          if(event.keyCode === 37){
              playerMove(-1);//sets boundry
              //decreases the player x position
          } else if(event.keyCode === 39){ //condition for keyboard event right
            playerMove(+1);//sets boundry
             //increases the player x position
        } else if(event.keyCode === 40){ //condition for keyboard event down
             //increases the player y position
            //reset the drop counter for re use
            playerDrop();
        } else if (event.keyCode === 81){

            playerRotate(-1);
        } else if (event.keyCode === 87){

            playerRotate(1);
        }


        })
        playerReset();
     
        update();//initialise game
        updateScore();
    }

    render(){


        return(
           
            <div className = "tetris">
                <canvas ref = "canvas" width = {240} height ={400} pos = "true"/>

                <div id = "score">High Score</div>
                
            </div>
        )
    }
}

export default Tetris