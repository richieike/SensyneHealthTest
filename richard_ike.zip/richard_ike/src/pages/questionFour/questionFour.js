
const QuestionFour = () =>{
	throw new Error("The choice is your's Captain");
}

export default QuestionFour