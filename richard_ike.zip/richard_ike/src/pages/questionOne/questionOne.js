import React, { Component } from 'react';
import Button from '@material-ui/core/Button';

class QuestionOne extends Component {
	constructor(props){
		super(props);
		this.state = {
			label: "I've been clicked: ",
			counter: 0
		}
	}

	/*
	I always use event handler like below - this issue previously was the click event was called within the render
	the value that was set to state  on a onClick event in the render which  causes a re render 
	 */
	handleClickSubmit = (e) => {

		e.preventDefault(); 
		this.setState({
			counter: this.state.counter + 1
		})



	}
	render(){
		
		return (
			<div style={{marginTop: 48}}>
				<Button   variant="contained" onClick = {this.handleClickSubmit.bind(this)} >
					{this.state.label} {this.state.counter} times
				</Button>
			</div>
		)
	}
}

export default QuestionOne