import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';

import Paper from '@material-ui/core/Paper';

import Android from "@material-ui/icons/Android";
import Pets from "@material-ui/icons/Pets";
import BugReport from "@material-ui/icons/BugReport";

import { createRowData } from './mocks'
import QuestionListItem from './QuestionListItem';

const createMockData = () => {
	/* Please do not refactor this function */
	return [
		createRowData({ species: 'Robot', name: 'T-100', Icon: Android, description: "Likes long walks, walking over the bones of it's enemies" }),
		createRowData({ species: 'Bug', name: 'Barry', Icon: BugReport, description: "Likes long walks, and creating problems in all your code" }),
		createRowData({ species: 'Rabbit', name: 'Roger', Icon: Pets, description: "Likes long walks and getting to know the inner you" }),
		createRowData({ species: null, name: null, Icon: null, description: null })
	]
};

const useStyles = makeStyles(() => ({
	container: {
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
		height: '100%',
	},
	root: {
		width: '100%',
	},
	inline: {
		display: 'inline',
	},
}));

 const QuestionThree = props =>  {
	

		const classes = useStyles(makeStyles);
		const {container, root, inline} = classes;
		console.log("classes for render", container, root,inline);
		//const [createRowData1, createRowData2, createRowData3, createRowData4] = createMockData();
		
		const res = createMockData();
		console.log("res!",res);

		return (
		
			<div className={container}>
				<Paper>
					<List className={root}>
						<React.Fragment>

						{res.map((item, i) => {
							return <QuestionListItem  item={item} key={item.id} divider={i !== res.length - 1} /> 
					
						})}
					
						</React.Fragment>				
					</List>
				</Paper>
			</div>
			
		)

		
		
	}

export default QuestionThree