import React, {Fragment } from 'react'
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';

import Divider from '@material-ui/core/Divider';
const useStyles = makeStyles(() => ({
	header: {
		fontWeight: 'bold',
		display: 'inline',
		marginRight: 4,
	},
	label: {
		display: 'inline',
	},
}));



const QuestionListItem = props => {
	console.log("Props", props)
		const {item:{icon, name, species, id,divider, description} } = props;
		
		const classes = useStyles(makeStyles);
		const {header, label} = classes;
		
		
		return(
			<div>
						<Fragment>
				<ListItem alignItems="flex-start" >
					<ListItemAvatar>
						<Avatar variant = {'circle'}
							alt = {'icon'}
							component ={icon}
							src ={`${icon}`}
							children ={`${icon}`}
						/>
					</ListItemAvatar>
					<div>
					<ListItemText
						primary={`${name}:  ${species? species : 'Other'}`}
						secondary={
								<>
									<Typography component={'span'} variant={'body2'}
										
										className={header}
									>
										Description:
									</Typography>
									<Typography
										component={'span'} variant={'body2'}
										className={label}
									>
										{description}
									</Typography>
								
									<br>
									</br>
									<Typography
										component={'span'} variant={'body2'}
										className={header}
									>
										Guid:
									</Typography>
									<Typography
										component={'span'} variant={'body2'}
										className={classes.label}
									>
										{id ? id : 'ERROR '}
									</Typography>
								

						</>
						}
					/>
					</div>
					
				</ListItem>
				{divider && <Divider variant="middle" />}
			</Fragment>

			</div>
		
		);
} 

export default QuestionListItem;


